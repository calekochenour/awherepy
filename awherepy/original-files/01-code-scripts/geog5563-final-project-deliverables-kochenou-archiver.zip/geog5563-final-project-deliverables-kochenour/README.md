This folder contains the contents of the GEOG 5563 final project.

aWhere API Python Solution Blog Post:

* awhere-data-python-kochenour.ipynb
* awhere-data-python-kochenour.html

aWhere API Python Solution Examples:

* awhere-classes-methods-python-examples-kochenour.ipynb
* awhere-classes-methods-python-examples-kochenour.html

Custom Python Scripts:

* awhere_classes.py
* awhere_grid.py
